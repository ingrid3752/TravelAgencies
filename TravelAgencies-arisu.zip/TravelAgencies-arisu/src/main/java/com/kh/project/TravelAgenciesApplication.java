package com.kh.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAgenciesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAgenciesApplication.class, args);
	}

}
