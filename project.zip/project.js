<script>
    function navigateTo(url) {
        window.location.href = 'hotel.html'
    };


</script>